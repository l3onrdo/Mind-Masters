Recreation of the game called Mastermind. 
